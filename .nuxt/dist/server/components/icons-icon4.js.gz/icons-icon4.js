exports.ids = [91];
exports.modules = {

/***/ 329:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/@nuxt/components/dist/loader.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./node_modules/unplugin/dist/webpack/loaders/transform.js??ref--13-0!./components/icons/icons-icon4.vue?vue&type=template&id=4766fcfa&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('svg',{attrs:{"xmlns":"http://www.w3.org/2000/svg","width":"41","height":"30","viewBox":"0 0 41 30"}},[_vm._ssrNode("<g><g><g><g><g><path fill=\"currentColor\" d=\"M38 27.503c0 .454-.325.844-.715.844h-.844c-.065.52-.455.975-.91.975H20.913a6.394 6.394 0 0 0 1.43-1.105l.324-.39-.065-1.169h14.683c.39 0 .715.39.715.845z\"></path></g> <g><path fill=\"currentColor\" d=\"M39.624 8.467c-.455-.585-1.104-.91-1.819-.91H17.99c-1.105 0-2.014.78-2.21 1.95l-.779 3.703c.26.26.585.454.715.52l.974.324.845-4.093c.065-.195.195-.39.455-.39h19.815c.195 0 .325.13.325.195.065.065.13.195.065.39l-2.729 13.449H22.343l.194 2.014H37.09l3.054-15.073c.065-.715-.065-1.43-.52-2.08z\"></path></g></g> <g><g><path fill=\"currentColor\" d=\"M18.185 29.322v-8.186c0-1.235-1.04-2.274-2.274-2.274H5.84c-1.235 0-2.274 1.04-2.274 2.274v8.186c-1.43-.52-2.6-1.17-3.314-1.884l.325-3.833V21.33l.26-3.249c0-.13-.13-1.819 2.079-2.144h.065l3.443-1.04c.065 0 .065 0 .065-.064.195-.13.78-.52 1.235-.975a.493.493 0 0 1 .26-.13h5.717c.13 0 .195.065.26.13.454.455 1.04.845 1.234.975l.065.065 3.443 1.04h.065c2.21.324 2.08 1.948 2.08 2.143l.26 3.249v2.274l.324 3.898c-.585.65-1.754 1.299-3.248 1.819z\"></path></g> <g><path fill=\"currentColor\" d=\"M9.219 11.52c.52.39 1.104.585 1.689.585s1.17-.195 1.69-.585c.779-.52 1.364-1.364 1.753-2.209.65-1.299.91-2.793.845-4.223-.065-.78-.195-1.624-.585-2.338C13.897 1.385 12.337.865 10.843.8c-1.43.065-2.989.585-3.768 1.95-.39.714-.52 1.559-.585 2.338-.065 1.43.195 2.924.845 4.223.52.845 1.104 1.625 1.884 2.21z\"></path></g></g></g></g></g>")])}
var staticRenderFns = []


// CONCATENATED MODULE: ./components/icons/icons-icon4.vue?vue&type=template&id=4766fcfa&

// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__(3);

// CONCATENATED MODULE: ./components/icons/icons-icon4.vue

var script = {}


/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  script,
  render,
  staticRenderFns,
  false,
  null,
  null,
  "6335e616"
  
)

/* harmony default export */ var icons_icon4 = __webpack_exports__["default"] = (component.exports);

/***/ })

};;
//# sourceMappingURL=icons-icon4.js.map