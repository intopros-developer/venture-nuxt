exports.ids = [96];
exports.modules = {

/***/ 333:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/@nuxt/components/dist/loader.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./node_modules/unplugin/dist/webpack/loaders/transform.js??ref--13-0!./components/icons/icons-instagram-color.vue?vue&type=template&id=681194ba&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('svg',{attrs:{"xmlns":"http://www.w3.org/2000/svg","width":"26","height":"26","viewBox":"0 0 26 26"}},[_vm._ssrNode("<defs>","</defs>",[_c('linearGradient',{attrs:{"id":"ugyma","x1":"22.05","x2":"5.74","y1":"6.12","y2":"20.04","gradientUnits":"userSpaceOnUse"}},[_c('stop',{attrs:{"offset":"0","stop-color":"#cc9518"}}),_vm._v(" "),_c('stop',{attrs:{"offset":".71","stop-color":"#a82d54"}}),_vm._v(" "),_c('stop',{attrs:{"offset":"1","stop-color":"#822da8"}})],1)],1),_vm._ssrNode(" <g><g clip-path=\"url(#clip-a17265f8-c5ec-488e-a758-e6facbdc1b59)\"><path fill=\"url(#ugyma)\" d=\"M19.236 12.997a6.255 6.255 0 1 1-12.51 0 6.255 6.255 0 0 1 12.51 0zm-6.255 4.06a4.06 4.06 0 1 0 0-8.12 4.06 4.06 0 0 0 0 8.12zm6.502-9.101a1.462 1.462 0 1 1 0-2.924 1.462 1.462 0 0 1 0 2.924zM12.68.816c-3.034 0-3.462.016-4.721.073-1.297.059-2.182.265-2.957.566a5.968 5.968 0 0 0-2.157 1.406A5.96 5.96 0 0 0 1.44 5.018c-.3.774-.506 1.66-.565 2.957C.814 9.273.8 9.689.8 12.997c0 3.308.013 3.723.073 5.023.059 1.296.264 2.181.565 2.956a5.97 5.97 0 0 0 1.406 2.158 5.956 5.956 0 0 0 2.157 1.404c.775.3 1.66.507 2.957.567 1.3.06 1.714.073 5.022.073 3.309 0 3.723-.014 5.022-.073 1.297-.06 2.183-.266 2.958-.567a5.956 5.956 0 0 0 2.157-1.404 5.978 5.978 0 0 0 1.405-2.158c.301-.775.507-1.66.566-2.956.057-1.26.072-1.688.073-4.721v-.604c0-3.033-.016-3.462-.073-4.72-.06-1.297-.265-2.183-.566-2.957a5.968 5.968 0 0 0-1.405-2.157 5.968 5.968 0 0 0-2.157-1.406C20.186 1.154 19.3.948 18.003.89c-1.258-.057-1.687-.073-4.72-.074zm.301 2.194c3.253 0 3.638.013 4.922.072 1.188.054 1.833.252 2.263.419.568.22.974.485 1.4.912.426.425.69.83.912 1.4.166.43.364 1.075.418 2.262.06 1.285.072 1.67.072 4.922s-.013 3.638-.072 4.922c-.054 1.188-.252 1.833-.418 2.262a3.8 3.8 0 0 1-.912 1.4 3.77 3.77 0 0 1-1.4.911c-.43.168-1.075.366-2.263.42-1.284.059-1.669.071-4.922.071-3.253 0-3.638-.012-4.922-.07-1.188-.055-1.833-.253-2.262-.42a3.77 3.77 0 0 1-1.4-.911 3.78 3.78 0 0 1-.912-1.401c-.167-.43-.366-1.074-.42-2.262-.057-1.284-.07-1.67-.07-4.922 0-3.253.013-3.637.07-4.922.054-1.187.253-1.833.42-2.263.221-.568.485-.974.912-1.4.426-.426.832-.69 1.4-.911.429-.167 1.074-.365 2.262-.42 1.284-.058 1.67-.07 4.922-.07\"></path></g></g>")],2)}
var staticRenderFns = []


// CONCATENATED MODULE: ./components/icons/icons-instagram-color.vue?vue&type=template&id=681194ba&

// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__(3);

// CONCATENATED MODULE: ./components/icons/icons-instagram-color.vue

var script = {}


/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  script,
  render,
  staticRenderFns,
  false,
  null,
  null,
  "90b8bafa"
  
)

/* harmony default export */ var icons_instagram_color = __webpack_exports__["default"] = (component.exports);

/***/ })

};;
//# sourceMappingURL=icons-instagram-color.js.map