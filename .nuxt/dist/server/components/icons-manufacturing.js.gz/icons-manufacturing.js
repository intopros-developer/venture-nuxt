exports.ids = [99];
exports.modules = {

/***/ 215:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/@nuxt/components/dist/loader.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./node_modules/unplugin/dist/webpack/loaders/transform.js??ref--13-0!./components/icons/icons-manufacturing.vue?vue&type=template&id=9240c354&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('svg',{staticClass:"h-4 w-4",attrs:{"xmlns":"http://www.w3.org/2000/svg","width":"29","height":"22","viewBox":"0 0 29 22"}},[_vm._ssrNode("<g><g clip-path=\"url(#clip-ea89d3f9-1644-4153-ada0-920febeac331)\"><path fill=\"#f6fafd\" d=\"M.886 10.965v-.606l.346-.29c.646-.155 1.165-.282 1.683-.407C4.657 9.43 6.428 9.33 8.28 8.638c.588 0 1.375.097 2.124-.03.608-.105 1.205-.116 1.821-.141.377-.273.63-.621.698-1.111.065-.469.344-.868.495-1.316.36-1.064.841-2.084 1.253-3.13.204-.519.364-1.053.593-1.725.29-.228.696-.545 1.003-.784.523-.102.934-.244 1.346-.244.411-.001.824.14 1.208.214l.562.668c.126 1.068.199 2.388.534 3.679.105.403.019.859.02 1.29v1.737c.195.33.413.424.774.255.371-.174.782-.26 1.318-.432 1.04-1.064 2.445-1.887 3.846-2.715.128-.077.276-.128.391-.22.676-.544 1.432-.754 2.353-.561.015.28.03.578.04.827l-2.225 4.218v3.924c.745 1.476 1.48 2.926 2.203 4.382.05.097.007.24.007.427-.554.095-1.102.025-1.657.047-1.76-1.076-3.56-2.107-5.06-3.671-.644.114-1.174-.664-1.99-.322v.426a8.673 8.673 0 0 1-.33 2.594c-.197.684-.168 1.438-.209 2.163-.027.524-.005 1.049-.005 1.677-.327.257-.7.551-1.05.83h-1.756c-.109-.088-.235-.263-.393-.301-.951-.227-1.213-.981-1.432-1.786a2.738 2.738 0 0 0-.26-.662c-.19-.321-.184-.715-.337-1.01-.17-.33-.35-.616-.334-1.003.004-.105-.095-.216-.147-.324-.358-.748-.61-1.537-.852-2.327-.111-.359-.222-.692-.572-.892-.826-.107-1.664-.146-2.48-.378-.315-.09-.676.002-1.013-.029-.387-.036-.789-.06-1.15-.186-1.255-.437-2.53-.725-3.864-.75-.347-.006-.69-.174-1.033-.266-.43-.114-.862-.226-1.366-.219l-.468-.496\"></path></g></g>")])}
var staticRenderFns = []


// CONCATENATED MODULE: ./components/icons/icons-manufacturing.vue?vue&type=template&id=9240c354&

// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__(3);

// CONCATENATED MODULE: ./components/icons/icons-manufacturing.vue

var script = {}


/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  script,
  render,
  staticRenderFns,
  false,
  null,
  null,
  "01b53bf9"
  
)

/* harmony default export */ var icons_manufacturing = __webpack_exports__["default"] = (component.exports);

/***/ })

};;
//# sourceMappingURL=icons-manufacturing.js.map