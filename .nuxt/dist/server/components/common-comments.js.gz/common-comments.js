exports.ids = [26];
exports.modules = {

/***/ 258:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/@nuxt/components/dist/loader.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./node_modules/unplugin/dist/webpack/loaders/transform.js??ref--13-0!./components/common/common-comments.vue?vue&type=template&id=0aff4b5d&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('section',{staticClass:"container bg-white py-8 antialiased lg:py-16 dark:bg-gray-900"},[_vm._ssrNode("<div class=\"mx-auto max-w-2xl\">","</div>",[_vm._ssrNode("<div class=\"mb-6 flex items-center justify-between\"><h2 class=\"text-lg font-bold text-gray-900 lg:text-2xl dark:text-white\">Discussion (20)</h2></div> <form class=\"mb-6\"><div class=\"mb-4 rounded-lg rounded-t-lg border border-gray-200 bg-white px-4 py-2 dark:border-gray-700 dark:bg-gray-800\"><label for=\"comment\" class=\"sr-only\">Your comment</label> <textarea id=\"comment\" rows=\"6\" placeholder=\"Write a comment...\" required=\"required\" class=\"w-full border-0 px-0 text-sm text-gray-900 focus:outline-none focus:ring-0 dark:bg-gray-800 dark:text-white dark:placeholder-gray-400\"></textarea></div> <button type=\"submit\" class=\"focus:ring-primary-200 dark:focus:ring-primary-900 hover:bg-primary-800 inline-flex items-center rounded-lg bg-primary-700 px-4 py-2.5 text-center text-xs font-medium text-white focus:ring-4\">\n                Post comment\n            </button></form> "),_vm._ssrNode("<article class=\"rounded-lg bg-white p-6 text-base dark:bg-gray-900\">","</article>",[_vm._ssrNode("<footer class=\"mb-2 flex items-center justify-between\">","</footer>",[_vm._ssrNode("<div class=\"flex items-center\">","</div>",[_vm._ssrNode("<p class=\"mr-3 inline-flex items-center text-sm font-semibold text-gray-900 dark:text-white\">","</p>",[_c('nuxt-img',{staticClass:"mr-2 h-6 w-6 rounded-full",attrs:{"format":"webp","src":"https://flowbite.com/docs/images/people/profile-picture-2.jpg","alt":"Michael Gough","loading":"lazy"}}),_vm._ssrNode(" Michael Gough\n                    ")],2),_vm._ssrNode(" <p class=\"text-sm text-gray-600 dark:text-gray-400\"><time pubdate datetime=\"2022-02-08\" title=\"February 8th, 2022\">Feb. 8, 2022</time></p>")],2),_vm._ssrNode(" <button id=\"dropdownComment1Button\" data-dropdown-toggle=\"dropdownComment1\" type=\"button\" class=\"inline-flex items-center rounded-lg bg-white p-2 text-center text-sm font-medium text-gray-500 hover:bg-gray-100 focus:outline-none focus:ring-4 focus:ring-gray-50 dark:bg-gray-900 dark:text-gray-400 dark:hover:bg-gray-700 dark:focus:ring-gray-600\"><svg aria-hidden=\"true\" xmlns=\"http://www.w3.org/2000/svg\" fill=\"currentColor\" viewBox=\"0 0 16 3\" class=\"h-4 w-4\"><path d=\"M2 0a1.5 1.5 0 1 1 0 3 1.5 1.5 0 0 1 0-3Zm6.041 0a1.5 1.5 0 1 1 0 3 1.5 1.5 0 0 1 0-3ZM14 0a1.5 1.5 0 1 1 0 3 1.5 1.5 0 0 1 0-3Z\"></path></svg> <span class=\"sr-only\">Comment settings</span></button> <div id=\"dropdownComment1\" class=\"z-10 hidden w-36 divide-y divide-gray-100 rounded bg-white shadow dark:divide-gray-600 dark:bg-gray-700\"><ul aria-labelledby=\"dropdownMenuIconHorizontalButton\" class=\"py-1 text-sm text-gray-700 dark:text-gray-200\"><li><button aria-label=\"Edit\" class=\"block px-4 py-2 hover:bg-gray-100 dark:hover:bg-gray-600 dark:hover:text-white\">Edit</button></li> <li><button aria-label=\"Remove\" class=\"block px-4 py-2 hover:bg-gray-100 dark:hover:bg-gray-600 dark:hover:text-white\">Remove</button></li> <li><button aria-label=\"Report\" class=\"block px-4 py-2 hover:bg-gray-100 dark:hover:bg-gray-600 dark:hover:text-white\">Report</button></li></ul></div>")],2),_vm._ssrNode(" <p class=\"text-gray-500 dark:text-gray-400\">\n                Very straight-to-point article. Really worth time reading. Thank you! But tools are just the instruments for the UX designers. The knowledge of the design tools are as important as the creation of the design strategy.\n            </p> <div class=\"mt-4 flex items-center space-x-4\"><button type=\"button\" class=\"flex items-center text-sm font-medium text-gray-500 hover:underline dark:text-gray-400\"><svg aria-hidden=\"true\" xmlns=\"http://www.w3.org/2000/svg\" fill=\"none\" viewBox=\"0 0 20 18\" class=\"mr-1.5 h-3.5 w-3.5\"><path stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\" stroke-width=\"2\" d=\"M5 5h5M5 8h2m6-3h2m-5 3h6m2-7H2a1 1 0 0 0-1 1v9a1 1 0 0 0 1 1h3v5l5-5h8a1 1 0 0 0 1-1V2a1 1 0 0 0-1-1Z\"></path></svg>\n                    Reply\n                </button></div>")],2),_vm._ssrNode(" "),_vm._ssrNode("<article class=\"mb-3 ml-6 rounded-lg bg-white p-6 text-base lg:ml-12 dark:bg-gray-900\">","</article>",[_vm._ssrNode("<footer class=\"mb-2 flex items-center justify-between\">","</footer>",[_vm._ssrNode("<div class=\"flex items-center\">","</div>",[_vm._ssrNode("<p class=\"mr-3 inline-flex items-center text-sm font-semibold text-gray-900 dark:text-white\">","</p>",[_c('nuxt-img',{staticClass:"mr-2 h-6 w-6 rounded-full",attrs:{"format":"webp","src":"https://flowbite.com/docs/images/people/profile-picture-5.jpg","alt":"Jese Leos","loading":"lazy"}}),_vm._ssrNode(" Jese Leos\n                    ")],2),_vm._ssrNode(" <p class=\"text-sm text-gray-600 dark:text-gray-400\"><time pubdate datetime=\"2022-02-12\" title=\"February 12th, 2022\">Feb. 12, 2022</time></p>")],2),_vm._ssrNode(" <button id=\"dropdownComment2Button\" data-dropdown-toggle=\"dropdownComment2\" type=\"button\" class=\"dark:text-gray-40 inline-flex items-center rounded-lg bg-white p-2 text-center text-sm font-medium text-gray-500 hover:bg-gray-100 focus:outline-none focus:ring-4 focus:ring-gray-50 dark:bg-gray-900 dark:hover:bg-gray-700 dark:focus:ring-gray-600\"><svg aria-hidden=\"true\" xmlns=\"http://www.w3.org/2000/svg\" fill=\"currentColor\" viewBox=\"0 0 16 3\" class=\"h-4 w-4\"><path d=\"M2 0a1.5 1.5 0 1 1 0 3 1.5 1.5 0 0 1 0-3Zm6.041 0a1.5 1.5 0 1 1 0 3 1.5 1.5 0 0 1 0-3ZM14 0a1.5 1.5 0 1 1 0 3 1.5 1.5 0 0 1 0-3Z\"></path></svg> <span class=\"sr-only\">Comment settings</span></button> <div id=\"dropdownComment2\" class=\"z-10 hidden w-36 divide-y divide-gray-100 rounded bg-white shadow dark:divide-gray-600 dark:bg-gray-700\"><ul aria-labelledby=\"dropdownMenuIconHorizontalButton\" class=\"py-1 text-sm text-gray-700 dark:text-gray-200\"><li><button aria-label=\"Edit\" class=\"block px-4 py-2 hover:bg-gray-100 dark:hover:bg-gray-600 dark:hover:text-white\">Edit</button></li> <li><button aria-label=\"Remove\" class=\"block px-4 py-2 hover:bg-gray-100 dark:hover:bg-gray-600 dark:hover:text-white\">Remove</button></li> <li><button aria-label=\"Report\" class=\"block px-4 py-2 hover:bg-gray-100 dark:hover:bg-gray-600 dark:hover:text-white\">Report</button></li></ul></div>")],2),_vm._ssrNode(" <p class=\"text-gray-500 dark:text-gray-400\">Much appreciated! Glad you liked it ☺️</p> <div class=\"mt-4 flex items-center space-x-4\"><button type=\"button\" class=\"flex items-center text-sm font-medium text-gray-500 hover:underline dark:text-gray-400\"><svg aria-hidden=\"true\" xmlns=\"http://www.w3.org/2000/svg\" fill=\"none\" viewBox=\"0 0 20 18\" class=\"mr-1.5 h-3.5 w-3.5\"><path stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\" stroke-width=\"2\" d=\"M5 5h5M5 8h2m6-3h2m-5 3h6m2-7H2a1 1 0 0 0-1 1v9a1 1 0 0 0 1 1h3v5l5-5h8a1 1 0 0 0 1-1V2a1 1 0 0 0-1-1Z\"></path></svg>\n                    Reply\n                </button></div>")],2),_vm._ssrNode(" "),_vm._ssrNode("<article class=\"mb-3 border-t border-gray-200 bg-white p-6 text-base dark:border-gray-700 dark:bg-gray-900\">","</article>",[_vm._ssrNode("<footer class=\"mb-2 flex items-center justify-between\">","</footer>",[_vm._ssrNode("<div class=\"flex items-center\">","</div>",[_vm._ssrNode("<p class=\"mr-3 inline-flex items-center text-sm font-semibold text-gray-900 dark:text-white\">","</p>",[_c('nuxt-img',{staticClass:"mr-2 h-6 w-6 rounded-full",attrs:{"format":"webp","src":"https://flowbite.com/docs/images/people/profile-picture-3.jpg","alt":"Bonnie Green","loading":"lazy"}}),_vm._ssrNode(" Bonnie Green\n                    ")],2),_vm._ssrNode(" <p class=\"text-sm text-gray-600 dark:text-gray-400\"><time pubdate datetime=\"2022-03-12\" title=\"March 12th, 2022\">Mar. 12, 2022</time></p>")],2),_vm._ssrNode(" <button id=\"dropdownComment3Button\" data-dropdown-toggle=\"dropdownComment3\" type=\"button\" class=\"dark:text-gray-40 inline-flex items-center rounded-lg bg-white p-2 text-center text-sm font-medium text-gray-500 hover:bg-gray-100 focus:outline-none focus:ring-4 focus:ring-gray-50 dark:bg-gray-900 dark:hover:bg-gray-700 dark:focus:ring-gray-600\"><svg aria-hidden=\"true\" xmlns=\"http://www.w3.org/2000/svg\" fill=\"currentColor\" viewBox=\"0 0 16 3\" class=\"h-4 w-4\"><path d=\"M2 0a1.5 1.5 0 1 1 0 3 1.5 1.5 0 0 1 0-3Zm6.041 0a1.5 1.5 0 1 1 0 3 1.5 1.5 0 0 1 0-3ZM14 0a1.5 1.5 0 1 1 0 3 1.5 1.5 0 0 1 0-3Z\"></path></svg> <span class=\"sr-only\">Comment settings</span></button> <div id=\"dropdownComment3\" class=\"z-10 hidden w-36 divide-y divide-gray-100 rounded bg-white shadow dark:divide-gray-600 dark:bg-gray-700\"><ul aria-labelledby=\"dropdownMenuIconHorizontalButton\" class=\"py-1 text-sm text-gray-700 dark:text-gray-200\"><li><button aria-label=\"Edit\" class=\"block px-4 py-2 hover:bg-gray-100 dark:hover:bg-gray-600 dark:hover:text-white\">Edit</button></li> <li><button aria-label=\"Remove\" class=\"block px-4 py-2 hover:bg-gray-100 dark:hover:bg-gray-600 dark:hover:text-white\">Remove</button></li> <li><button aria-label=\"Report\" class=\"block px-4 py-2 hover:bg-gray-100 dark:hover:bg-gray-600 dark:hover:text-white\">Report</button></li></ul></div>")],2),_vm._ssrNode(" <p class=\"text-gray-500 dark:text-gray-400\">The article covers the essentials, challenges, myths and stages the UX designer should consider while creating the design strategy.</p> <div class=\"mt-4 flex items-center space-x-4\"><button type=\"button\" class=\"flex items-center text-sm font-medium text-gray-500 hover:underline dark:text-gray-400\"><svg aria-hidden=\"true\" xmlns=\"http://www.w3.org/2000/svg\" fill=\"none\" viewBox=\"0 0 20 18\" class=\"mr-1.5 h-3.5 w-3.5\"><path stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\" stroke-width=\"2\" d=\"M5 5h5M5 8h2m6-3h2m-5 3h6m2-7H2a1 1 0 0 0-1 1v9a1 1 0 0 0 1 1h3v5l5-5h8a1 1 0 0 0 1-1V2a1 1 0 0 0-1-1Z\"></path></svg>\n                    Reply\n                </button></div>")],2),_vm._ssrNode(" "),_vm._ssrNode("<article class=\"border-t border-gray-200 bg-white p-6 text-base dark:border-gray-700 dark:bg-gray-900\">","</article>",[_vm._ssrNode("<footer class=\"mb-2 flex items-center justify-between\">","</footer>",[_vm._ssrNode("<div class=\"flex items-center\">","</div>",[_vm._ssrNode("<p class=\"mr-3 inline-flex items-center text-sm font-semibold text-gray-900 dark:text-white\">","</p>",[_c('nuxt-img',{staticClass:"mr-2 h-6 w-6 rounded-full",attrs:{"format":"webp","src":"https://flowbite.com/docs/images/people/profile-picture-4.jpg","alt":"Helene Engels","loading":"lazy"}}),_vm._ssrNode(" Helene Engels\n                    ")],2),_vm._ssrNode(" <p class=\"text-sm text-gray-600 dark:text-gray-400\"><time pubdate datetime=\"2022-06-23\" title=\"June 23rd, 2022\">Jun. 23, 2022</time></p>")],2),_vm._ssrNode(" <button id=\"dropdownComment4Button\" data-dropdown-toggle=\"dropdownComment4\" type=\"button\" class=\"dark:text-gray-40 inline-flex items-center rounded-lg bg-white p-2 text-center text-sm font-medium text-gray-500 hover:bg-gray-100 focus:outline-none focus:ring-4 focus:ring-gray-50 dark:bg-gray-900 dark:hover:bg-gray-700 dark:focus:ring-gray-600\"><svg aria-hidden=\"true\" xmlns=\"http://www.w3.org/2000/svg\" fill=\"currentColor\" viewBox=\"0 0 16 3\" class=\"h-4 w-4\"><path d=\"M2 0a1.5 1.5 0 1 1 0 3 1.5 1.5 0 0 1 0-3Zm6.041 0a1.5 1.5 0 1 1 0 3 1.5 1.5 0 0 1 0-3ZM14 0a1.5 1.5 0 1 1 0 3 1.5 1.5 0 0 1 0-3Z\"></path></svg></button> <div id=\"dropdownComment4\" class=\"z-10 hidden w-36 divide-y divide-gray-100 rounded bg-white shadow dark:divide-gray-600 dark:bg-gray-700\"><ul aria-labelledby=\"dropdownMenuIconHorizontalButton\" class=\"py-1 text-sm text-gray-700 dark:text-gray-200\"><li><button aria-label=\"Edit\" class=\"block px-4 py-2 hover:bg-gray-100 dark:hover:bg-gray-600 dark:hover:text-white\">Edit</button></li> <li><button aria-label=\"Remove\" class=\"block px-4 py-2 hover:bg-gray-100 dark:hover:bg-gray-600 dark:hover:text-white\">Remove</button></li> <li><button aria-label=\"Report\" class=\"block px-4 py-2 hover:bg-gray-100 dark:hover:bg-gray-600 dark:hover:text-white\">Report</button></li></ul></div>")],2),_vm._ssrNode(" <p class=\"text-gray-500 dark:text-gray-400\">Thanks for sharing this. I do came from the Backend development and explored some of the tools to design my Side Projects.</p> <div class=\"mt-4 flex items-center space-x-4\"><button type=\"button\" class=\"flex items-center text-sm font-medium text-gray-500 hover:underline dark:text-gray-400\"><svg aria-hidden=\"true\" xmlns=\"http://www.w3.org/2000/svg\" fill=\"none\" viewBox=\"0 0 20 18\" class=\"mr-1.5 h-3.5 w-3.5\"><path stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\" stroke-width=\"2\" d=\"M5 5h5M5 8h2m6-3h2m-5 3h6m2-7H2a1 1 0 0 0-1 1v9a1 1 0 0 0 1 1h3v5l5-5h8a1 1 0 0 0 1-1V2a1 1 0 0 0-1-1Z\"></path></svg>\n                    Reply\n                </button></div>")],2)],2)])}
var staticRenderFns = []


// CONCATENATED MODULE: ./components/common/common-comments.vue?vue&type=template&id=0aff4b5d&

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--3-0!./node_modules/@nuxt/components/dist/loader.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./node_modules/unplugin/dist/webpack/loaders/transform.js??ref--13-0!./components/common/common-comments.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* harmony default export */ var common_commentsvue_type_script_lang_js_ = ({
  data() {
    return {
      comment: ''
    };
  },
  methods: {
    createComments() {},
    getAllComments() {}
  }
});
// CONCATENATED MODULE: ./components/common/common-comments.vue?vue&type=script&lang=js&
 /* harmony default export */ var common_common_commentsvue_type_script_lang_js_ = (common_commentsvue_type_script_lang_js_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__(3);

// CONCATENATED MODULE: ./components/common/common-comments.vue





/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  common_common_commentsvue_type_script_lang_js_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  "6c3290e5"
  
)

/* harmony default export */ var common_comments = __webpack_exports__["default"] = (component.exports);

/***/ })

};;
//# sourceMappingURL=common-comments.js.map