exports.ids = [12,82];
exports.modules = {

/***/ 154:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/@nuxt/components/dist/loader.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./node_modules/unplugin/dist/webpack/loaders/transform.js??ref--13-0!./components/icons/icons-downarrow.vue?vue&type=template&id=0715fdf0&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('svg',{attrs:{"xmlns":"http://www.w3.org/2000/svg","width":"11","height":"6","viewBox":"0 0 11 6"}},[_vm._ssrNode("<g><g><path fill=\"currentColor\" d=\"M.439.546l4.907 4.907L10.254.546z\"></path></g></g>")])}
var staticRenderFns = []


// CONCATENATED MODULE: ./components/icons/icons-downarrow.vue?vue&type=template&id=0715fdf0&

// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__(3);

// CONCATENATED MODULE: ./components/icons/icons-downarrow.vue

var script = {}


/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  script,
  render,
  staticRenderFns,
  false,
  null,
  null,
  "ddee2f3c"
  
)

/* harmony default export */ var icons_downarrow = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ 299:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/@nuxt/components/dist/loader.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./node_modules/unplugin/dist/webpack/loaders/transform.js??ref--13-0!./components/career/career-company-overview.vue?vue&type=template&id=39096253&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('section',{staticClass:"py-10 md:pb-20 md:pt-36 xl:pb-[85px] xl:pt-12"},[_vm._ssrNode("<div class=\"container px-10 md:px-4 lg:px-[97px] xl:px-4\">","</div>",[_vm._ssrNode("<div class=\"mb-8 flex items-center justify-center gap-[33px] text-center\"><div class=\"hidden h-px w-full bg-[#d5d5d5] sm:block\"></div> <h2 class=\"text-2xl font-bold text-black sm:shrink-0 xl:text-3xl\">Careers with Venture Plans</h2> <div class=\"hidden h-px w-full bg-[#d5d5d5] sm:block\"></div></div> "),_vm._ssrNode("<div class=\"space-y-9 text-sm font-medium leading-6 text-black-700 xl:text-xl xl:leading-9\">","</div>",[_vm._ssrNode("<div"+(_vm._ssrClass("relative h-20 overflow-hidden",{ '!h-full': _vm.isShowReadMore }))+"><p class=\"whitespace-pre-line\">\n                    An applicant's average writing time to a comprehensive business plan is 70-100 hours, including an attorney's time to review. We cut that time to 3 Days by sharing our systems and strategies to writing an immigration\n                    compliant business plan with you. It's important to note that on average USCIS looks for business plans that are 25-35 pages. Here we focus on your investment, the source of capital and your personal capacity to grow\n                    and direct the company efficiently. It is recommended that a detailed business plan with financial forecasts for a five-year period be obtained when the decision on the form of business to buy or develop has been\n                    created. The Business Plan is an important document as it is your chance to justify and clarify your business enterprise and qualify for your investment. The intended growth and economic effect that your business\n                    would have in the United States should be discussed.\n                </p> <div"+(_vm._ssrClass("absolute inset-x-0 bottom-0 h-9 bg-[#FBFBFD]/50 backdrop-blur-sm",{ hidden: _vm.isShowReadMore }))+"></div></div> "),_vm._ssrNode("<div class=\"text-center\">","</div>",[(!_vm.isShowReadMore)?_vm._ssrNode("<button"+(_vm._ssrAttr("aria-label",_vm.$t('read_more')))+" class=\"flex items-center justify-center gap-4 text-sm font-semibold text-primary xl:text-xl\">","</button>",[_vm._ssrNode("<p class=\"text-base\">"+_vm._ssrEscape(_vm._s(_vm.$t('read_more')))+"</p> "),_c('icons-downarrow',{staticClass:"w-2 xl:w-[11px]"})],2):_vm._ssrNode("<button"+(_vm._ssrAttr("aria-label",_vm.$t('read_less')))+" class=\"flex items-center justify-center gap-4 text-sm font-semibold text-primary xl:text-xl\">","</button>",[_vm._ssrNode("<p class=\"text-base\">"+_vm._ssrEscape(_vm._s(_vm.$t('read_less')))+"</p> "),_c('icons-downarrow',{staticClass:"w-2 rotate-180 xl:w-[11px]"})],2)])],2),_vm._ssrNode(" <div class=\"mb-7 flex items-center justify-center gap-[33px] pt-10 text-center lg:mb-[67px] xl:pt-[117px]\"><div class=\"hidden h-px w-full bg-[#d5d5d5] sm:block\"></div> <h2 class=\"text-2xl font-bold text-black sm:shrink-0 xl:text-3xl\">Overview</h2> <div class=\"hidden h-px w-full bg-[#d5d5d5] sm:block\"></div></div> "),_vm._ssrNode("<div class=\"flex flex-col lg:flex-row\">","</div>",[_vm._ssrNode("<div class=\"mx-auto w-full flex-none lg:max-w-[332px] xl:max-w-[425px]\"><div><ul class=\"md:space-y-3\">"+(_vm._ssrList((_vm.serviceOptions),function(service,index){return ("<li"+(_vm._ssrClass("cursor-pointer py-4 leading-[45px] -tracking-[0.04px] md:py-2.5 lg:text-[21px]",[_vm.params.service === service ? 'border-b border-[#1a9cea] font-bold text-[#1a9cea]' : 'border-b border-[#bfbfbf]']))+">"+_vm._ssrEscape("\n                            "+_vm._s(service)+"\n                        ")+"</li>")}))+"</ul></div></div> "),_vm._ssrNode("<div>","</div>",[(_vm.params.service === 'Harvard Graduate Applications' || _vm.params.service === 'Qualifications')?_vm._ssrNode("<div class=\"bg-white p-5 shadow-[0_3px_6px_rgba(0,0,0,0.16)] md:px-8 md:pb-16 md:pt-8\">","</div>",[_c('nuxt-img',{staticClass:"h-full w-full object-cover",attrs:{"format":"webp","src":"/assets/img/video-img-1.png","alt":"Take your business to the next level","loading":"lazy"}}),_vm._ssrNode(" <div class=\"pt-5 md:pt-8\"><h4 class=\"text-xl -tracking-[-0.06px] text-[#2F2F2F] md:text-2xl lg:text-[32px]\">Take your business to the next level</h4> <p class=\"pt-[21px] text-sm -tracking-[0.04px] text-[#4d4d4d]\">\n                            See where you're strong, where you lag, and what the savings potential can be when you improve specific elements of your performance and capability. Our benchmarking database of 250+ plants across a wide\n                            variety of industries captures today's most relevant KPIs, allowing you to visualize your current state, spot areas of opportunity and prioritize the actions that will vault you ahead of your competitors.\n                        </p> <button aria-label=\"Learn More\" class=\"inline-block pt-6 font-semibold leading-[23px] text-[#0da1f1]\">Learn More</button></div>")],2):(_vm.params.service === 'Available Intern Positions' || _vm.params.service === 'About The Workplace')?_vm._ssrNode("<div class=\"bg-white p-5 shadow-[0_3px_6px_rgba(0,0,0,0.16)] md:px-8 md:pb-16 md:pt-8\">","</div>",[_c('nuxt-img',{staticClass:"h-full w-full object-cover",attrs:{"format":"webp","src":"/assets/img/video-img.png","alt":"Take your business to the next level","loading":"lazy"}}),_vm._ssrNode(" <div class=\"pt-5 md:pt-8\"><h4 class=\"text-xl -tracking-[-0.06px] text-[#2F2F2F] md:text-2xl lg:text-[32px]\">Take your business to the next level</h4> <p class=\"pt-[21px] text-sm -tracking-[0.04px] text-[#4d4d4d]\">\n                            See where you're strong, where you lag, and what the savings potential can be when you improve specific elements of your performance and capability. Our benchmarking database of 250+ plants across a wide\n                            variety of industries captures today's most relevant KPIs, allowing you to visualize your current state, spot areas of opportunity and prioritize the actions that will vault you ahead of your competitors.\n                        </p> <button aria-label=\"Learn More\" class=\"inline-block pt-6 font-semibold leading-[23px] text-[#0da1f1]\">Learn More</button></div>")],2):(_vm.params.service === 'Elite Level Environment Overview' || _vm.params.service === 'Establish A New Franchising Company' || _vm.params.service === 'Investor Relations Software (Ai)')?_vm._ssrNode("<div class=\"bg-white p-5 shadow-[0_3px_6px_rgba(0,0,0,0.16)] md:px-8 md:pb-16 md:pt-8\">","</div>",[_c('nuxt-img',{staticClass:"h-full w-full object-cover",attrs:{"format":"webp","src":"/assets/img/que-1.jpg","alt":"Take your business to the next level","loading":"lazy"}}),_vm._ssrNode(" <div class=\"pt-5 md:pt-8\"><h4 class=\"text-xl -tracking-[-0.06px] text-[#2F2F2F] md:text-2xl lg:text-[32px]\">Take your business to the next level</h4> <p class=\"pt-[21px] text-sm -tracking-[0.04px] text-[#4d4d4d]\">\n                            See where you're strong, where you lag, and what the savings potential can be when you improve specific elements of your performance and capability. Our benchmarking database of 250+ plants across a wide\n                            variety of industries captures today's most relevant KPIs, allowing you to visualize your current state, spot areas of opportunity and prioritize the actions that will vault you ahead of your competitors.\n                        </p> <button aria-label=\"Learn More\" class=\"inline-block pt-6 font-semibold leading-[23px] text-[#0da1f1]\">Learn More</button></div>")],2):_vm._ssrNode("<div class=\"bg-white p-5 shadow-[0_3px_6px_rgba(0,0,0,0.16)] md:px-8 md:pb-16 md:pt-8\">","</div>",[_c('nuxt-img',{staticClass:"h-full w-full object-cover",attrs:{"format":"webp","src":"/assets/img/que-2.jpg","alt":"Take your business to the next level","loading":"lazy"}}),_vm._ssrNode(" <div class=\"pt-5 md:pt-8\"><h4 class=\"text-xl -tracking-[-0.06px] text-[#2F2F2F] md:text-2xl lg:text-[32px]\">Take your business to the next level</h4> <p class=\"pt-[21px] text-sm -tracking-[0.04px] text-[#4d4d4d]\">\n                            See where you're strong, where you lag, and what the savings potential can be when you improve specific elements of your performance and capability. Our benchmarking database of 250+ plants across a wide\n                            variety of industries captures today's most relevant KPIs, allowing you to visualize your current state, spot areas of opportunity and prioritize the actions that will vault you ahead of your competitors.\n                        </p> <button aria-label=\"Learn More\" class=\"inline-block pt-6 font-semibold leading-[23px] text-[#0da1f1]\">Learn More</button></div>")],2)])],2),_vm._ssrNode(" "),_vm._ssrNode("<div class=\"mt-10 text-center md:mt-16 xl:mt-[110px]\">","</div>",[_c('nuxt-link',{staticClass:"b-btn px-4 py-[31px] text-sm uppercase -tracking-[0.03px]",attrs:{"to":"book-consult"}},[_vm._v("BOOK YOUR INTERVIEW")])],1)],2)])}
var staticRenderFns = []


// CONCATENATED MODULE: ./components/career/career-company-overview.vue?vue&type=template&id=39096253&

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--3-0!./node_modules/@nuxt/components/dist/loader.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./node_modules/unplugin/dist/webpack/loaders/transform.js??ref--13-0!./components/career/career-company-overview.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* harmony default export */ var career_company_overviewvue_type_script_lang_js_ = ({
  props: {
    value: {
      type: String,
      default: ''
    }
  },
  data() {
    return {
      isShowReadMore: false,
      isShowOptions: false,
      serviceOptions: ["What we're looking for at Venture Plans", 'Available Intern Positions', 'Harvard Graduate Applications', 'Elite Level Environment Overview', 'Establish A New Franchising Company', 'About The Workplace', 'Qualifications'],
      params: {
        service: "What we're looking for at Venture Plans"
      }
    };
  }
});
// CONCATENATED MODULE: ./components/career/career-company-overview.vue?vue&type=script&lang=js&
 /* harmony default export */ var career_career_company_overviewvue_type_script_lang_js_ = (career_company_overviewvue_type_script_lang_js_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__(3);

// CONCATENATED MODULE: ./components/career/career-company-overview.vue



function injectStyles (context) {
  
  
}

/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  career_career_company_overviewvue_type_script_lang_js_,
  render,
  staticRenderFns,
  false,
  injectStyles,
  null,
  "3a6470cc"
  
)

/* harmony default export */ var career_company_overview = __webpack_exports__["default"] = (component.exports);

/* nuxt-component-imports */
installComponents(component, {IconsDownarrow: __webpack_require__(154).default})


/***/ })

};;
//# sourceMappingURL=career-company-overview.js.map