exports.ids = [80];
exports.modules = {

/***/ 325:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/@nuxt/components/dist/loader.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./node_modules/unplugin/dist/webpack/loaders/transform.js??ref--13-0!./components/icons/icons-domain.vue?vue&type=template&id=67e465d0&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('svg',{attrs:{"xmlns":"http://www.w3.org/2000/svg","width":"67","height":"67","viewBox":"0 0 67 67"}},[_vm._ssrNode("<g><g><g><g><g><g><path fill=\"currentColor\" d=\"M62.111 61.82H4.418V11.58h23.16a3.27 3.27 0 0 0 2.932-1.84l1.351-2.786a1.44 1.44 0 0 1 1.3-.81h13.305c.551 0 1.06.311 1.3.81l1.351 2.786a3.27 3.27 0 0 0 2.932 1.84H62.11zM8.462 3.805a2.653 2.653 0 0 1 2.661 2.66 2.653 2.653 0 0 1-2.66 2.662A2.66 2.66 0 0 1 5.8 6.466a2.66 2.66 0 0 1 2.661-2.661zm7.952 0a2.653 2.653 0 0 1 2.661 2.66 2.653 2.653 0 0 1-2.66 2.662 2.653 2.653 0 0 1-2.662-2.661 2.653 2.653 0 0 1 2.661-2.661zm7.953 0a2.66 2.66 0 0 1 2.66 2.66 2.66 2.66 0 0 1-2.66 2.662 2.662 2.662 0 1 1 0-5.322zM64.325 0H2.205A2.214 2.214 0 0 0 0 2.214v61.81c0 1.226.998 2.213 2.204 2.213h62.121a2.214 2.214 0 0 0 2.204-2.214V2.214A2.214 2.214 0 0 0 64.325 0z\"></path></g></g></g> <g><g><g><path fill=\"currentColor\" d=\"M32.11 17.193v8.576a47.97 47.97 0 0 1-6.766-.613c.831-3.118 1.985-5.644 3.274-7.443a19.388 19.388 0 0 1 3.493-.52z\"></path></g></g> <g><g><path fill=\"currentColor\" d=\"M32.11 28.067v7.484h-8.16c.063-2.973.375-5.717.874-8.16a50.02 50.02 0 0 0 7.287.676z\"></path></g></g> <g><g><path fill=\"currentColor\" d=\"M32.11 47.64v8.577a20.358 20.358 0 0 1-3.492-.52c-1.289-1.809-2.443-4.325-3.274-7.443a47.97 47.97 0 0 1 6.767-.613z\"></path></g></g> <g><g><path fill=\"currentColor\" d=\"M25.27 18.867c-.862 1.694-1.6 3.66-2.172 5.852a35.203 35.203 0 0 1-4.22-1.247 19.46 19.46 0 0 1 6.393-4.605z\"></path></g></g> <g><g><path fill=\"currentColor\" d=\"M25.27 54.543a19.502 19.502 0 0 1-6.392-4.605 31.303 31.303 0 0 1 4.22-1.247c.572 2.193 1.31 4.158 2.173 5.852z\"></path></g></g> <g><g><path fill=\"currentColor\" d=\"M22.579 26.944c-.541 2.65-.863 5.54-.926 8.607h-7.9a19.486 19.486 0 0 1 3.607-10.218 34.226 34.226 0 0 0 5.219 1.611z\"></path></g></g> <g><g><path fill=\"currentColor\" d=\"M32.11 37.848v7.495c-2.556.052-5.01.281-7.286.676-.499-2.453-.81-5.187-.873-8.17z\"></path></g></g> <g><g><path fill=\"currentColor\" d=\"M22.579 46.456c-1.892.436-3.639.977-5.219 1.621a19.52 19.52 0 0 1-3.607-10.229h7.9c.063 3.067.385 5.967.926 8.608z\"></path></g></g> <g><g><path fill=\"currentColor\" d=\"M41.175 25.156a47.972 47.972 0 0 1-6.767.613v-8.576c1.206.063 2.37.25 3.503.52 1.29 1.799 2.433 4.325 3.264 7.443z\"></path></g></g> <g><g><path fill=\"currentColor\" d=\"M42.568 35.551h-8.16v-7.484a50.166 50.166 0 0 0 7.298-.676c.488 2.443.8 5.187.862 8.16z\"></path></g></g> <g><g><path fill=\"currentColor\" d=\"M41.175 48.254c-.831 3.118-1.975 5.634-3.264 7.443-1.133.27-2.297.447-3.503.52V47.64a47.97 47.97 0 0 1 6.767.613z\"></path></g></g> <g><g><path fill=\"currentColor\" d=\"M47.651 23.472a35.203 35.203 0 0 1-4.22 1.248c-.582-2.194-1.31-4.159-2.172-5.853a19.569 19.569 0 0 1 6.393 4.605z\"></path></g></g> <g><g><path fill=\"currentColor\" d=\"M47.651 49.938a19.721 19.721 0 0 1-6.392 4.605c.862-1.694 1.59-3.66 2.172-5.852 1.539.343 2.942.769 4.22 1.247z\"></path></g></g> <g><g><path fill=\"currentColor\" d=\"M52.776 35.551h-7.91a49.1 49.1 0 0 0-.915-8.607 33.728 33.728 0 0 0 5.208-1.611c2.09 2.91 3.399 6.424 3.617 10.218z\"></path></g></g> <g><g><path fill=\"currentColor\" d=\"M42.568 37.848c-.062 2.984-.374 5.718-.862 8.171a48.758 48.758 0 0 0-7.298-.676v-7.495z\"></path></g></g> <g><g><path fill=\"currentColor\" d=\"M52.776 37.848a19.442 19.442 0 0 1-3.617 10.23c-1.57-.645-3.316-1.186-5.208-1.622.53-2.64.852-5.541.915-8.608z\"></path></g></g></g></g></g></g>")])}
var staticRenderFns = []


// CONCATENATED MODULE: ./components/icons/icons-domain.vue?vue&type=template&id=67e465d0&

// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__(3);

// CONCATENATED MODULE: ./components/icons/icons-domain.vue

var script = {}


/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  script,
  render,
  staticRenderFns,
  false,
  null,
  null,
  "0faf8399"
  
)

/* harmony default export */ var icons_domain = __webpack_exports__["default"] = (component.exports);

/***/ })

};;
//# sourceMappingURL=icons-domain.js.map