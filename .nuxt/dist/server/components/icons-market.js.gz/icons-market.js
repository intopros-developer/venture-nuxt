exports.ids = [100];
exports.modules = {

/***/ 334:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/@nuxt/components/dist/loader.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./node_modules/unplugin/dist/webpack/loaders/transform.js??ref--13-0!./components/icons/icons-market.vue?vue&type=template&id=d2007f4c&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('svg',{attrs:{"xmlns":"http://www.w3.org/2000/svg","width":"68","height":"66","viewBox":"0 0 68 66"}},[_vm._ssrNode("<g><g><g><g><path fill=\"currentColor\" d=\"M12.439 41.159v9.436c0 .858.643 1.501 1.501 1.501h8.221a1.51 1.51 0 0 0 1.501-1.5v-9.437c-1.787.429-3.646.715-5.576.715-2.001-.072-3.86-.286-5.647-.715z\"></path></g> <g><path fill=\"currentColor\" d=\"M30.811 37.942v12.582a1.51 1.51 0 0 0 1.501 1.5h8.221c.858 0 1.502-.643 1.502-1.5V30.65c0-.858-.644-1.501-1.502-1.501h-1.787c-1.93 3.574-4.647 6.648-7.935 8.793z\"></path></g> <g><path fill=\"currentColor\" d=\"M58.834 57.458H13.94a1.51 1.51 0 0 0-1.501 1.501v5.004c0 .858.643 1.501 1.501 1.501h44.894a1.51 1.51 0 0 0 1.501-1.5v-5.005c-.071-.858-.715-1.501-1.501-1.501z\"></path></g> <g><path fill=\"currentColor\" d=\"M67.412 15.209L56.546.91c-.929-1.215-2.788-1.215-3.717 0L41.963 15.21c-1.144 1.573-.071 3.789 1.859 3.789h5.29v31.526c0 .857.643 1.5 1.501 1.5h8.221a1.51 1.51 0 0 0 1.501-1.5V18.998h5.29c1.859 0 3.003-2.216 1.788-3.79z\"></path></g> <g><path fill=\"currentColor\" d=\"M16.085 30.364v-2.001c-2.36-.286-4.218-2.145-4.504-4.576 0-.214.071-.429.214-.572.143-.142.358-.285.572-.285h2.36c.357 0 .643.214.714.571.143.572.644 1.001 1.287 1.001h2.073c1.072 0 2.002-.786 2.145-1.787.071-.572-.143-1.144-.5-1.573-.358-.429-.93-.643-1.502-.643h-1.501c-3.074 0-5.79-2.288-6.077-5.219-.285-3.074 1.788-5.79 4.719-6.29V6.988c0-.429.357-.786.786-.786h2.288c.429 0 .786.357.786.786V8.99c2.359.285 4.218 2.144 4.504 4.575a.812.812 0 0 1-.215.572c-.143.143-.357.286-.572.286h-2.359c-.357 0-.643-.215-.715-.572a1.31 1.31 0 0 0-1.286-1.001h-2.074c-1.072 0-2.001.786-2.144 1.787-.072.572.143 1.144.5 1.573.358.429.93.643 1.501.643h1.86c1.643 0 3.216.715 4.288 1.93 1.144 1.216 1.645 2.86 1.502 4.504-.215 2.502-2.217 4.575-4.719 5.076v2.144a.793.793 0 0 1-.786.787h-2.288c-.5-.143-.857-.5-.857-.93zM36.1 18.712C36.101 8.704 28.023.626 18.015.626 8.078.626 0 8.704 0 18.712s8.078 18.015 18.015 18.015c10.008 0 18.086-8.078 18.086-18.015z\"></path></g></g></g></g>")])}
var staticRenderFns = []


// CONCATENATED MODULE: ./components/icons/icons-market.vue?vue&type=template&id=d2007f4c&

// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__(3);

// CONCATENATED MODULE: ./components/icons/icons-market.vue

var script = {}


/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  script,
  render,
  staticRenderFns,
  false,
  null,
  null,
  "c72871de"
  
)

/* harmony default export */ var icons_market = __webpack_exports__["default"] = (component.exports);

/***/ })

};;
//# sourceMappingURL=icons-market.js.map